package Snake;
import javax.swing.*;
import java.awt.*;

public class StartGame {
    public static void main(String[] args){
        JFrame frame = new JFrame();
        frame.setBounds(10,10,900,720);
        frame.setLocation(300,100);
        frame.setResizable(false);
        frame.add(new GamePanel());
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
