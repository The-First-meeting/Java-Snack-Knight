import ui.GameFrame;

public class Run {
    //主函数，程序入口
    public static void main(String[] args) throws Exception {
        GameFrame gf = new GameFrame();
    }
}
