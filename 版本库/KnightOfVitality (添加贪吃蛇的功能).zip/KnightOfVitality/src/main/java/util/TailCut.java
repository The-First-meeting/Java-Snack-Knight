package util;

public class TailCut {
}
