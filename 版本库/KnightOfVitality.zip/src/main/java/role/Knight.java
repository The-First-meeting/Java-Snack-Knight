package role;

import ui.GameFrame;
import util.Hit;
import util.Winner;

import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Knight implements Runnable{

    public GameFrame gf;
    public int kx;
    public int ky;
    JLabel jknight=new JLabel(new ImageIcon("image/knight.png"));
    public boolean bool;
    Hit hit=new Hit();
    public Knight(GameFrame gf)
    {
        this.gf=gf;

        //设置骑士的初始位置
        this.gf.add(jknight);
        jknight.setBounds(100,20,20,20);
        this.kx=100;
        this.ky=20;
        System.out.println("骑士坐标设置成功");
        gf.getLayeredPane().add(jknight, Integer.valueOf(Integer.MAX_VALUE));
        //this.run();
    }


    @Override
    public void run() {
        this.kx=kx;
        this.ky=ky;
        this.gf.addKeyListener(
                new KeyAdapter() {
                    public void keyPressed(KeyEvent e) {

                        //while(true)
                        //{
                            int keyCode=e.getKeyCode();
                            if (keyCode==KeyEvent.VK_UP)
                            {
                                System.out.println("你按下了上键");
                                bool= hit.hitCheck(kx,ky,1, gf.map);
                                if(bool) ky-=20;
                            }
                            if (keyCode==KeyEvent.VK_DOWN)
                            {
                                System.out.println("你按下了下键");
                                bool= hit.hitCheck(kx,ky,2, gf.map);
                                if(bool) ky+=20;
                            }
                            if (keyCode==KeyEvent.VK_LEFT)
                            {
                                System.out.println("你按下了左键");
                                bool= hit.hitCheck(kx,ky,3, gf.map);
                                if(bool) kx-=20;
                            }
                            if (keyCode==KeyEvent.VK_RIGHT)
                            {
                                System.out.println("你按下了右键");
                                bool= hit.hitCheck(kx,ky,4, gf.map);

                                if(bool) kx+=20;

                            }
                            System.out.println(bool);
                            System.out.println(kx+" "+ky);
                            jknight.setBounds(kx,ky,20,20);
                            //检测胜利
                        if (kx==160&&ky==300)
                        {
                            //获得胜利
                            Winner winner=new Winner();
                            winner.winner();
                        }

                        //}

                    }
                }
        );
    }
}
