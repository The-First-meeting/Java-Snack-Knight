toward,ax,ay,end,setx,sety
toward：朝向，1234对应上下左右
ax：发射点的x坐标
ay：发射点的y坐标
end：停止的x坐标或y坐标（由于是直线，确定了朝向就只需要一个end限制）
setx：蛇头触发陷阱的x坐标
sety：蛇头触发陷阱的y坐标