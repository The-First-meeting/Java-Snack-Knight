bx,by
bx:金币横坐标
by:金币纵坐标