toward,kx,ky
toward:人物朝向，1234对应上下左右
kx:人物横坐标
ky:人物纵坐标