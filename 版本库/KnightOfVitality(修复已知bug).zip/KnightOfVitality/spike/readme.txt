sx,sy
sx:地刺横坐标
sy:地刺纵坐标