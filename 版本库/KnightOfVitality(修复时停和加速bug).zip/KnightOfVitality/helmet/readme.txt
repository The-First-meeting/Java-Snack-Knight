hel_num
hel_num:拥有头盔数量